<template>
  <div class="upload">
    <Modal v-model="modal" :closable="false" :mask-closable="false">
      <Upload
        multiple
        type="drag"
        action="//jsonplaceholder.typicode.com/posts/"
        accept=".mp4,.avi,.mov,.wmv,.flv"
        :format="['mp4','avi','mov','wmv','flv']"
        :on-format-error="formatError"
        >
        <div style="padding: 20px 0">
          <Icon type="ios-cloud-upload" size="52" style="color: #3399ff"></Icon>
          <p>点击此处或拖拽视频到此处上传到服务器</p>
          <p>支持的格式有.mp4/.avi/.mov/.wmv/.flv</p>
        </div>
      </Upload>
    </Modal>
    <div class="upload-box">
      <div class="head">
        <div class="title"><span class="lf">视频</span><router-link :to="{ name: 'videos'}" style="cursor:pointer" tag="span" class="rt">视频管理</router-link></div>
      </div>
      <div class="video-loader">
        <div class="center">
          <p>您还没有上传过视频！</p>
          <!-- 传说中的实名认证和开放注册，后面被莫名其妙砍掉了 -->
          <!-- <input type="button" @click="showModal('upload')" value="立即上传" class="btn main-btn"/> -->
          <input type="button" @click="modal = true" value="立即上传" class="btn main-btn"/>
        </div>
      </div>
    </div>
    <div class="bodan">
      <div class="head">
        <div class="title"><span class="lf">播单</span><router-link :to="{ name: 'bodanlist'}" style="cursor:pointer" tag="span" class="rt">播单管理</router-link></div>
      </div>
      <div class="video-loader">
        <div class="center">
          <p>这个播单内容不多哦 快丰富一下吧~</p>
          <!-- <input type="button" @click="showModal('bodan')" value="创建播单" class="btn main-btn"/> -->
          <input type="button" @click="modal1 = true" value="创建播单" class="btn main-btn"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import Modal from "../modal/TeacherMainModal";
export default {
  // components: { Modal },
  data() {
    return {
      modal: false,
      modal1:false
    };
  },
  methods: {
    formatError(){
      console.log('formatE')
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../assets/style/base.scss";
.active {
  border-bottom: 1px solid $red;
}
.upload-box,
.bodan {
  border: 1px solid $border-dark;
  margin-bottom: 20px;
  .head {
    .lf {
      float: left;
    }
    .rt {
      float: right;
    }
    .title {
      background-color: $bg-nav;
      line-height: 35px;
      overflow: hidden;
      span {
        width: 70px;
        text-align: center;
      }
    }
  }
  .video-loader {
    height:200px;
  }
}
.btn {
  padding: 10px;
  color: $white;
  background-color: $red;
  border: none;
  outline: none;
  display: block;
  margin: 0 auto;
  cursor: pointer;
}
.center {
  position: relative;
  top: 20%;
  p {
    text-align: center;
    margin-bottom: 10px;
  }
}
</style>

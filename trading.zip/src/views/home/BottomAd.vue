<template>
  <div class="bottom-ad">
    <div class="bottom-warp">
      <img src="../../assets/images/底部海报.png"/>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
@import '../../assets/style/base.scss';
  .bottom-ad{
    overflow: hidden;
    .bottom-warp{
      position: relative;
      height: 477px;
      // background: url('../../assets/images/haibao (1).png') center center;
      // background-size: 100% 100%;
    }
  }
</style>

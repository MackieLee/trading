.ivu-form-item.ivu-form-item<template>
  <div class="fagui">
    <div class="cur-posi">
      <p>
        <i></i>当前位置 : &nbsp;
        <router-link to="/home">九鼎财税</router-link>
        &nbsp;&gt;&nbsp;新法规
      </p>
    </div>
    <div class="main-title">
      {{ title }}
    </div>
    <div class="th">
      <table cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td class="xuhao ctr" style="width: 40px;">序号</td>
            <td class="biaoti" style="text-align:center;">标题</td>
            <td class="fahao ctr">文号发文</td>
            <td class="riqi ctr">日期</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="td">
      <table cellspacing="0" cellpadding="0">
        <tbody>
          <router-link v-for="(item,index) in list" :key="item.id" tag="tr" :to="{ name:'fdetail',query:{ id:item.id }}">
            <td class="xuhao pointer ctr">{{index+1}}</td>
            <td class="biaoti pointer">{{item.name}}</td>
            <td class="fahao pointer ctr">{{item.reference}}</td>
            <td class="riqi pointer ctr">{{item.date_posted}}</td>
          </router-link>
        </tbody>
      </table>
      <div class="pgs">
        <li class="prev">&lt;上一页</li>
        <li class="current ">1</li>
        <li class="custom">2</li>
        <li class="custom">3</li>
        <li class="custom">4</li>
        <li class="points">...</li>
        <li class="jump"><input type="tel" maxlength="3"> /40页</li>
        <li class="submit">确定</li>
        <li class="next">下一页&gt;</li>
      </div>
    </div>
  </div>
</template>

<script>
import { loginUserUrl } from '@/api/api'
export default {
  name: "fagui",
  data(){
    return{
      list:[],
      title:'法规列表'
    }
  },
  created () {
    let obj = this.$route.query
    let _self = this
    let res = loginUserUrl('http://aip.kehu.zaidayou.com/api/execute/getlaws_Search',{
      username: "niuhongda",
      password: "123123q",
      area:obj.area,
      name:obj.name,
      reference:obj.reference,
      date_posted:obj.date_posted,
      department:obj.department,
      begin_time:obj.begin_time,
      end_time:obj.end_time,
      laws:obj.laws
    }).then((res)=>{
      _self.list = res.data
      console.log(res.data)
    })
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/style/base.scss";
.fagui {
  width: $width;
  margin: 0 auto;
  overflow: hidden;
  padding-top: 20px;
  // border-top: 1px solid $border-rice;
  i {
    display: inline-block;
    width: 22px;
    height: 22px;
    background-image: url("../../assets/images/Sprite.png");
    vertical-align: text-bottom;
    background-position: 0px 30px;
    margin-right: 11px;
  }
  .jingxuan{
    width: 60px;
    height: 22px;
    background-position: 339px -12px;
  }
  .cur-posi {
    border-bottom: none;
    i {
      background-position: -18px -100px;
      margin-right: 6px;
    }
  }
  .main-title {
    line-height: 70px;
    font-size: 18px;
    color: $red;
    text-align: center;
  }
  .ctr {
    text-align: left;
  }
  .xuhao {
    width: 20px;
  }
  .fahao {
    width: 230px;
  }
  .riqi {
    width: 130px; padding-left: 20px;
  }
  .red {
    color: $red;
  }
  .pointer {
    cursor: pointer;
  }
  .th {
    height: 42px;
    font-weight: bold;
    background-color: $bg-blue;
    table {
      table-layout: fixed;
      border-collapse: separate;
      width: 96%; margin: 0px auto;
      td {
        display: table-cell;
        line-height: 42px;
        font-size: 14px;
        color: $white;
      }
    }
  }
  .td {
    font-weight: bold;
    border: 1px solid $border-blue;
    table {
      table-layout: fixed;
      border-collapse: separate;
      width: 96%; margin: 0 auto;
      tr:hover{
      	td{color: red;}
      }
      td {
        display: table-cell;
        line-height: 42px;
        font-size: 14px;
      }
      .separate{
        border-bottom: 1px solid $border-dark;
      }
    }
  }
  .pgs {
    width: 525px;
    margin: 60px auto;
    li {
      width: 33px;
      padding: 4px 0;
      line-height: 20px;
      text-align: center;
      margin-right: 2px;
      cursor: pointer;
      border: 1px solid $border-dark;
      color: $black;
    }
    .prev {
      width: 73px;
      color: $blue;
    }
    .next {
      width: 96px;
      color: $blue;
    }
    .points {
      border: none;
    }
    .submit {
      background-color: $btn-default;
      color: $white;
      width: 44px;
      border: none;
    }
    .jump {
      width: 80px;
      border: 1px solid $border-dark;
      color: #333;
      input {
        width: 30px;
        border: 1px solid $border-dark;
        outline: none;
      }
    }
    .current {
      background-color: $btn-default;
      color: $white;
    }
  }
}
</style>

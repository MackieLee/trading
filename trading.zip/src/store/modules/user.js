const user = {
  state: {
    userName:'',
    nickName:'',
    province:'',
    city:'',
    district:'',
    profession:'',
    occupation:'',
    companyName:'',
    companyScale:''
  },
  mutations: { },
  actions: { },
  getters: { }
}

export  default user
